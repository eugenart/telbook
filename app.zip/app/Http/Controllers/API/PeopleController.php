<?php

namespace App\Http\Controllers\API;

use App\People;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PeopleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $people = People::all();
        foreach ($people as $man) {
            $man->phone = unserialize($man->phone);
            $man->email = unserialize($man->email);
            $man->ip_phone = unserialize($man->ip_phone);
            $man->fax = unserialize($man->fax);
        }
        return $people;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'fio' => 'required|string',
            'position' => 'required|string',
            'email.*' => 'email'
        ]);

        //'fio', 'position', 'phone', 'ip_phone', 'building_id', 'group_id', 'room', 'room_type', 'email'


        return People::create([
            'fio' => $request['fio'],
            'position' => $request['position'],
            'priority' => $request['priority'],
            'phone' => serialize($request['phone']),
            'ip_phone' => serialize($request['ip_phone']),
            'building_id' => $request['building_id'],
            'group_id' => $request['group_id'],
            'room' => $request['room'],
            'room_type' => $request['room_type'],
            'email' => serialize($request['email']),
            'fax' => serialize($request['fax'])
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'fio' => 'required|string',
            'position' => 'required|string',
            'email.*' => 'email'
        ]);

        //'fio', 'position', 'phone', 'ip_phone', 'building_id', 'group_id', 'room', 'room_type', 'email'

        $data = ([
            'fio' => $request['fio'],
            'position' => $request['position'],
            'priority' => $request['priority'],
            'phone' => serialize($request['phone']),
            'ip_phone' => serialize($request['ip_phone']),
            'building_id' => $request['building_id'],
            'group_id' => $request['group_id'],
            'room' => $request['room'],
            'room_type' => $request['room_type'],
            'email' => serialize($request['email']),
            'fax' => serialize($request['fax']),
        ]);

        $man = People::findOrFail($id);
        $man->update($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $man = People::findOrFail($id);
        $man->delete();
        return ['message' => 'Group deleted!'];
    }

    public function search(Request $request)
    {
        $q = $request['q'];
        $people = People::where('fio', 'LIKE', "%$q%")
            ->orwhere('position', 'LIKE', "%$q%")
            ->orwhere('phone', 'LIKE', "%$q%")
            ->orwhere('fax', 'LIKE', "%$q%")
            ->orwhere('ip_phone', 'LIKE', "%$q%")
            ->get();
        foreach ($people as $person){
            $person->phone = unserialize($person->phone);
            $person->fax = unserialize($person->fax);
            $person->email = unserialize($person->email);
            $person->ip_phone = unserialize($person->ip_phone);
            $person->group_name =  $person->group->name;
            $person->building_name =  $person->building->name;
            $person->building_address =  $person->building->address;
        }
        return $people;

    }
}
