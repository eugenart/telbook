<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Телефонный справочник</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div id="app">
    <vue-progress-bar></vue-progress-bar>
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <router-link class="navbar-brand" to="/">
                Телефонный справочник
            </router-link>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <router-link class="nav-link" to="/search">Поиск <span class="sr-only">(current)</span>
                            </router-link>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <router-link class="nav-link" to="/admin/buildings">Здания <span
                                    class="sr-only">(current)</span>
                            </router-link>
                        </li>
                        <li class="nav-item">
                            <router-link class="nav-link" to="/admin/groups">Группы <span
                                    class="sr-only">(current)</span>
                            </router-link>
                        </li>
                        <li class="nav-item">
                            <router-link class="nav-link" to="/admin/people">Сотрудники <span
                                    class="sr-only">(current)</span>
                            </router-link>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Войти</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    Выйти
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4">
        <router-view></router-view>
    </main>
    <footer id="footer" class="row align-items-end" style="background-color: black;">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                    <div class="thumbnail">
                        <a href="http://mrsu.ru/" target="_blank">
                            <figure style="max-width: 300px; margin-left: auto; margin-right: auto;"><img
                                    class="ministr-logo" src="<?php echo e(asset('images/logo.png')); ?>" alt=""></figure>
                        </a>
                        <a href="http://minsvyaz.ru/ru/" target="_blank">
                            <figure style="max-width: 300px; margin-left: auto; margin-right: auto;"><img
                                    class="ministr-logo" src="<?php echo e(asset('images/mks_logo_shield.png')); ?>" alt=""></figure>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                    <div class="thumbnail">
                        <a href="https://rkn.gov.ru/" target="_blank">
                            <figure style="max-width: 300px; margin-left: auto; margin-right: auto;"><img
                                    class="ministr-logo" src="<?php echo e(asset('images/rkn.png')); ?>" alt=""></figure>
                        </a>
                        <a href="http://xn--80abucjiibhv9a.xn--p1ai/" target="_blank">
                            <figure style="max-width: 300px; margin-left: auto; margin-right: auto;"><img
                                    class="ministr-logo" src="<?php echo e(asset('images/logo.minobr.png')); ?>" alt=""></figure>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="thumbnail">
                        <p><i class="fab fa-internet-explorer"></i><a href="https://ci.mrsu.ru"> ci.mrsu.ru</a></p>
                        <p><i class="fa fa-envelope"></i><a href="mailto:ic@mrsu.ru"> ic@mrsu.ru</a></p>
                        <p><i class="fab fa-vk"></i><a href="https://vk.com/cimrsu"> vk.com/cimrsu</a></p>
                        <p><i class="fa fa-phone"></i><a href="tel:+78342777250"> +7 (8342) 777-250</a></p>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="footer2">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 panel">
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-6 panel">
                        <div class="panel-body">
                            <p class="text_right">
                                Copyright &copy; 2018. <br>Made by <br>Center Internet
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>

</body>
</html>
