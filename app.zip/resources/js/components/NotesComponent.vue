<template>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-3">
                <div id="accordion">
                    <div class="card mb-1" v-for="note in parentNotes">
                        <div class="card-header" :id="'heading'+ note.id">
                            <h4 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" :data-target="'#collapse'+ note.id"
                                        aria-expanded="true" :aria-controls="'collapse'+ note.id"
                                        @click="loadNotes(note.id)">
                                    {{ note.group_name }}
                                </button>
                            </h4>
                        </div>

                        <div :id="'collapse'+note.id" class="collapse hidden-part"
                             :aria-labelledby="'headingOne'+note.id"
                             data-parent="#accordion">
                            <div class="card-body">
                                <div class="list-group">
                                    <a href="#" class="list-group-item list-group-item-action"
                                       v-for="child in note.children" @click="loadNotes(child.id, child.name)">
                                        {{ child.name }} <br>
                                        <span class="child-info" v-for="phn in child.phone">
                                            <a :href="'tel:'+cityTypes[phn.phonePrefix -1]+phn.phoneNumber">{{ cityTypes[phn.phonePrefix -1] }}
                                            {{ phn.phoneNumber }}</a>
                                        </span>
                                        <br>
                                        <span class="child-info" v-for="ml in child.email">
                                            <a :href="'mailto:'+ml">{{ ml }} </a>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-9">
                <div class="table-responsive p-0 tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active">
                        <table class="table table-hover">
                            <thead>
                            <th width="15%">ФИО</th>
                            <th width="20%">Должность</th>
                            <th width="15%">Внешний номер</th>
                            <th width="10%">Внутренний номер</th>
                            <th width="15%">Факс</th>
                            <th width="10%">Email</th>
                            <th width="15%">Место</th>
                            </thead>
                            <tbody v-for='name in groupsNames'>
                            <tr class="group-tr">
                                <td colspan="7">
                                    <h3>{{ name }}
                                    </h3>
                                </td>
                            </tr>
                            <tr v-for="note in notes" v-if="note.group_info == name">
                                <td>{{ note.name }}</td>
                                <td>{{ note.position }}</td>
                                <td><span v-for="(phn, index) in note.phone" v-if="note.phone">
                                    <a :href="'tel:'+cityTypes[note.phone[index].phonePrefix -1]+note.phone[index].phoneNumber">{{ cityTypes[note.phone[index].phonePrefix -1] }}
                            {{ note.phone[index].phoneNumber }}</a>
                            <br>
                            </span>
                                </td>
                                <td><span v-for="(iphn, index) in note.ip_phone">{{ note.ip_phone[index] }}<br></span>
                                </td>
                                <td>
                            <span v-for="(fx, index) in note.fax" v-if="note.fax">
                            {{ cityTypes[note.fax[index].phonePrefix -1] }}
                            {{ note.fax[index].phoneNumber }}
                            <br>
                            </span>
                                </td>
                                <td><span v-for="(ml, index) in note.email"><a
                                    :href="'mailto:'+note.email[index]">{{ note.email[index] }} </a><br></span></td>
                                <td><a @prevent.click="" href="" v-b-popover.hover="note.address" title="Адрес">{{
                                    note.building }} {{ roomTypes[note.room_type -1] }} </a></td>
                                <!--{{ note.address }}-->
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                roomTypes: [
                    'кабинет',
                    'этаж'
                ],
                cityTypes: [
                    '+7 (8342)',
                    '+7 (83451)',
                    '+7 (83453)'
                ],
                notes: {},
                parentNotes: {},
                groupsNames: []
            }
        },

        methods: {
            loadNotes(id, name) {
                let names = [];
                axios.get('/api/note/' + id).then(({data}) => (this.notes = data,
                    data.forEach(function (item, i, data) {
                        names[i] = item.group_info
                        console.log(names[i])
                    }),
                    this.groupsNames = names.filter(this.onlyUnique),
                    console.log(names)))
            },

            loadParentNotes() {
                axios.get('/api/note').then(({data}) => (this.parentNotes = data))
            },

            onlyUnique(value, index, self) {
                return self.indexOf(value) === index;
            }
        }
        ,

        created() {
            this.loadParentNotes();
        }
    }
</script>

<style scoped>
    .group-tr {
        background-color: rgba(4, 30, 66, 0.9);
        color: white;
        cursor: pointer;
    }


    .group-tr:hover, .group-tr:hover a {
        color: black;
    }

    .group-tr a {
        color: white;
    }

    .card-header {
        background-color: rgba(4, 30, 66, 0.9);
    }

    .card-header button {
        color: white;
    }

    .card, .list-group-item {
        border-color: rgba(4, 30, 66, 0.9);
        font-size: 16px;
        font-weight: bolder;
    }

    .btn {
        font-size: 16px;
        font-weight: bolder;
    }

    .small-text {
        font-size: 14px;
    }

    .extra-link {
        color: white;
        text-decoration: underline;
    }

    .extra-link:hover {
        font-weight: bolder;
    }

</style>
