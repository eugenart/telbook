<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Группы</h4>
                        <div class="card-tools">
                            <button class="btn btn-success" @click="modalForNewGroup">Добавить
                                группу
                            </button>
                        </div>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover" v-show="groups.length > 0">
                            <thead>
                            <tr>
                                <th width="10%" scope="col">ID</th>
                                <th width="20%" scope="col">Название группы</th>
                                <th width="20%" scope="col">Родительская группа</th>
                                <th width="10%" scope="col">Email</th>
                                <th width="15%" scope="col">Телефон</th>
                                <th width="25%" scope="col">Редактирование</th>
                            </tr>
                            </thead>
                            <tbody>
                            <!-- //'name', 'parent_id', 'priority', 'email', 'phone'-->
                            <tr v-for="group in groups" :key="group.id" v-if="group.id">
                                <td>{{ group.id }}</td>
                                <td>{{ group.name }}</td>
                                <td>
                                    <span v-for="sub_group in groups" v-if="group.parent_id == sub_group.id">
                                        {{ sub_group.name }}
                                    </span>
                                </td>
                                <td>
                                    <p v-for="mail in group.email">
                                        {{ mail }}
                                    </p>
                                </td>
                                <td>
                                    <p v-for="phone in group.phone">
                                        {{ phoneTypes[phone.phoneType-1] }}
                                        <br>
                                        {{ cityTypes[phone.phonePrefix-1] }}
                                        {{ phone.phoneNumber }}<br>
                                    </p>

                                </td>
                                <td>
                                    <button class="btn btn-warning" @click="modalForChangeGroup(group)">
                                        Редактировать
                                    </button>
                                    <button @click="deleteGroup(group.id, group.name)"
                                            class="btn btn-danger">Удалить
                                    </button>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="GroupModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Добавление группы</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form @submit.prevent="editGroup ? updateGroup() : createGroup()">
                        <div class="modal-body">
                            <div class="input-group mb-3">
                                <model-list-select :list="newGroups" option-value="id" option-text="name"
                                                   v-model="form.parent_id" placeholder="Выберите родительский элемент">
                                </model-list-select>
                            </div>
                            <div class="form-group">
                                <input placeholder="Название группы" v-model="form.name" type="text" name="name"
                                       class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                                <has-error :form="form" field="name"></has-error>
                            </div>

                            <div class="form-group">
                                <button type="button" class="btn btn-primary" @click="addMail">Добавить почту</button>
                            </div>
                            <div class="form-row" v-for="(mail,index) in form.email">
                                <div class="form-group col-md-8">
                                    <input placeholder="Email" v-model="form.email[index]" type="text" name="email[]"
                                           class="form-control"
                                           :class="{ 'is-invalid': form.errors.has('form.email[index]') }">
                                    <has-error :form="form" field="form.email[index]"></has-error>
                                </div>
                                <div class="form-group col-md-4">
                                    <button @click="deleteMail(index)" type="button"
                                            class="btn btn-danger float-right">Удалить почту
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-primary" @click.prevent="addPhone()">Добавить номер
                                </button>
                            </div>
                            <div class="form-row" v-for="(phn,index) in form.phone">
                                <div class="form-group col-md-3">
                                    <select class="custom-select" v-model="form.phone[index].phoneType">
                                        <option value="1">Телефон</option>
                                        <option value="2">Факс</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <select class="custom-select" v-model="form.phone[index].phonePrefix">
                                        <option value="1">Саранск +7(8342)</option>
                                        <option value="2">Рузаевка +7(83451)</option>
                                        <option value="3">Ковылкино +7(83453)</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-3">
                                    <masked-input :mask="form.phone[index].phonePrefix == 1 ? '11-11-11' : '1-11-11'"
                                                  placeholder="Номер телефона" v-model="form.phone[index].phoneNumber"
                                                  type="text"
                                                  class="form-control"
                                                  :class="{ 'is-invalid': form.errors.has('form.phone[index].phoneNumber') }"/>
                                    <has-error :form="form" field="form.phone[index].phoneNumber"></has-error>
                                </div>
                                <div class="form-group col-md-3">
                                    <button @click.prevent="deletePhone(index)" type="button"
                                            class="btn btn-danger float-right">Удалить номер
                                    </button>
                                </div>
                            </div>
                            <div class="input-group mb-3">
                                <select class="custom-select" id="inputGroupSelect02"
                                        v-model="form.priority">
                                    <option value="1">Очень высокий</option>
                                    <option value="2">Высокий</option>
                                    <option value="3">Средний</option>
                                    <option value="4">Низкий</option>
                                    <option value="5">Очень низкий</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button v-show="!editGroup" type="submit" class="btn btn-success">Добавить группу
                            </button>
                            <button v-show="editGroup" type="submit" class="btn btn-primary">Сохранить изменения
                            </button>
                            <button type="button" class="btn btn-danger" @click.prevent="resetForm()"
                                    data-dismiss="modal">Закрыть
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import MaskedInput from "vue-masked-input";

    export default {
        components: {MaskedInput, ModelSelect, ModelListSelect},
        data() {
            return {
                phoneTypes: [
                    'Телефон',
                    'Факс'
                ],
                cityTypes: [
                    '+7(8342)',
                    '+7(83451)',
                    '+7(83453)'
                ],
                editGroup: true,
                groups: {},
                newGroups: [],
                form: new Form({ //'name', 'parent_id', 'priority', 'email', 'phone'
                    id: '',
                    name: '',
                    parent_id: '',
                    priority: '3',
                    email: [],
                    phone: []
                })
            }
        },


        methods: {
            addMail() {
                this.form.email.push('');
                this.form.clear();
            },

            deleteMail(index) {
                this.form.email.splice(index, 1);
            },

            addPhone() {
                this.form.phone.push({
                    phoneType: '',
                    phonePrefix: '1',
                    phoneNumber: ''
                });
                this.form.clear();
            },

            deletePhone(index) {
                this.form.phone.splice(index, 1);
            },

            updateGroup(id) {
                this.$Progress.start();
                this.form.put('/api/group/' + this.form.id)
                    .then(() => {
                        toast({
                            type: 'success',
                            title: 'Группа обновлена'
                        });
                        $('#GroupModal').modal('hide');
                        Fire.$emit('UpdateGroupTable');
                        this.$Progress.finish();
                    })
                    .catch(() => {
                        this.$Progress.fail();
                    })
            },

            createGroup() {
                this.$Progress.start()
                this.form.post('/api/group')
                    .then(() => {
                        Fire.$emit('UpdateGroupTable');
                        $('#GroupModal').modal('hide');
                        toast({
                            type: 'success',
                            title: 'Группа добавлена'
                        })
                        this.$Progress.finish();
                    })
                    .catch(() => {

                    })
            },

            loadGroups() {
                axios.get('/api/group?q=all')
                    .then(
                        ({data}) => (this.groups = data)
                    );
            },

            loadNewGroups() {
                axios.get('/api/group?q=parents')
                    .then(
                        ({data}) => (this.newGroups = data),
                        this.newGroups.unshift({
                            'id': ' ',
                            'name': 'Нет родительской группы'
                        }))
            },

            modalForNewGroup() {
                {
                    this.editGroup = false;
                    this.form.reset();
                    $('#GroupModal').modal('show');
                }
            },

            modalForChangeGroup(group) {
                let prev_group = JSON.parse(JSON.stringify(group));
                this.editGroup = true;
                this.form.reset();
                $('#GroupModal').modal('show');
                this.form.fill(prev_group);
                if (this.form.phone == []) {
                    this.form.phone = [];
                }
                ;
                if (this.form.email == []) {
                    this.form.email = [];
                }
            },

            deleteGroup(id, name) {
                swal({
                    title: 'Вы уверены?',
                    text: "После удаления будет невозможно восстановить данный элемент",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Удалить',
                    cancelButtonText: 'Отмена'
                }).then((result) => {

                        if (result.value) {
                            this.form.delete('/api/group/' + id).then(() => {
                                swal(
                                    'Группа ' + name + ' была удалена'
                                )
                                Fire.$emit('UpdateGroupTable');

                            }).catch(() => {
                                swal(
                                    'Группа ' + name + ' не была удалена', 'warning'
                                )

                            })
                        }
                    }
                )
            },

            resetForm() {
                this.form.reset();
            },

            seekChild() {
                console.log('wooow, children')
            }

        }
        ,

        created() {
            this.loadNewGroups();
            this.loadGroups();
            Fire.$on('UpdateGroupTable', () => {
                this.loadGroups();
            });
        }
    }
</script>

<style scoped>

</style>
