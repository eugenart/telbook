<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Здания</h4>
                        <div class="card-tools">
                            <button class="btn btn-success" @click="modalForNewBuilding">Добавить
                                здание
                            </button>
                        </div>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover" v-show="buildings.length > 0">
                            <thead>
                            <tr>
                                <th width="10%" scope="col">ID</th>
                                <th width="30%" scope="col">Название</th>
                                <th width="30%" scope="col">Адрес</th>
                                <th width="30%" scope="col">Редактирование</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr v-if="buildings" v-for="building in buildings" :key="building.id">
                                <td>{{ building.id }}</td>
                                <td>{{ building.name }}</td>
                                <td>{{ building.address }}</td>
                                <td>
                                    <button class="btn btn-warning" @click="modalForChangeBuilding(building)">Редактировать</button>
                                    <button @click="deleteBuilding(building.id, building.name)"
                                    class="btn btn-danger">Удалить</button>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="BuildingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 v-show="!editBuilding" class="modal-title">Добавление здания</h5>
                        <h5 v-show="editBuilding" class="modal-title">Изменение здания</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form @submit.prevent="editBuilding ? updateBuilding() : createBuilding()">
                        <div class="modal-body">
                            <div class="form-group">
                                <input placeholder="Название" v-model="form.name" type="text" name="name"
                                       class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                                <has-error :form="form" field="name"></has-error>
                            </div>
                            <div class="form-group">
                                <input placeholder="Адрес" v-model="form.address" type="text" name="address"
                                       class="form-control" :class="{ 'is-invalid': form.errors.has('address') }">
                                <has-error :form="form" field="address"></has-error>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button v-show="!editBuilding" type="submit" class="btn btn-primary">Добавить здание
                            </button>
                            <button v-show="editBuilding" type="submit" class="btn btn-success">Сохранить изменения
                            </button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Закрыть</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                editBuilding: true,
                buildings: {},
                form: new Form({
                    id: '',
                    name: '',
                    address: ''
                })
            }
        },

        methods: {
            updateBuilding(id) {
                this.$Progress.start();
                this.form.put('/api/building/' + this.form.id)
                    .then(() => {
                        toast({
                            type: 'success',
                            title: 'Здание обновлено'
                        });
                        $('#BuildingModal').modal('hide');
                        Fire.$emit('UpdateBuildingTable');
                        this.$Progress.finish();
                    })
                    .catch(() => {
                        this.$Progress.fail();
                    })
            }
            ,

            modalForNewBuilding() {
                this.editBuilding = false;
                this.form.reset();
                $('#BuildingModal').modal('show');
            }
            ,

            modalForChangeBuilding(building) {
                this.editBuilding = true;
                this.form.reset();
                $('#BuildingModal').modal('show');
                this.form.fill(building);
            }
            ,

            loadBuildings() {
                axios.get('/api/building').then(({data}) => (this.buildings = data, console.log(data.length)));
            }
            ,

            deleteBuilding(id, name) {
                swal({
                    title: 'Ву уверены?',
                    text: "После удаления будет невозможно восстановить данный элемент",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Удалить',
                    cancelButtonText: 'Отмена'
                }).then((result) => {

                        if (result.value) {
                            this.form.delete('/api/building/' + id).then(() => {
                                swal(
                                    'Здание ' + name + ' было удалено'
                                )
                                Fire.$emit('UpdateBuildingTable');

                            }).catch(() => {
                                swal(
                                    'Здание ' + name + 'не было удалено', 'warning'
                                )

                            })
                        }
                    }
                )
            }
            ,

            createBuilding() {
                console.log('create');
                this.$Progress.start()
                this.form.post('/api/building')
                    .then(() => {
                        Fire.$emit('UpdateBuildingTable');
                        $('#BuildingModal').modal('hide');
                        toast({
                            type: 'success',
                            title: 'Здание добавлено'
                        })
                        this.$Progress.finish();
                    })
                    .catch((e) => {
                        console.log(e);
                    })
            }
        },

        created() {
            this.loadBuildings();
            Fire.$on('UpdateBuildingTable', () => {
                this.loadBuildings();
            });
        }
    }
</script>
