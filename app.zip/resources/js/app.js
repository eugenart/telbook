require('./bootstrap');

window.Vue = require('vue');

import VueRouter from 'vue-router';
import {Form, HasError, AlertError} from 'vform';
import VueProgressBar from 'vue-progressbar';
import swal from 'sweetalert2';
import MaskedInput from 'vue-masked-input';
import {ModelSelect, ModelListSelect} from 'vue-search-select'
import {ServerTable, ClientTable, Event} from 'vue-tables-2';
import BootstrapVue from 'bootstrap-vue'

Vue.use(BootstrapVue);
Vue.component('pagination', require('laravel-vue-pagination'));
Vue.use(ClientTable);

window.ServerTable = ServerTable;
window.ClientTable = ClientTable;
window.MaskedInput = MaskedInput;
window.ModelSelect = ModelSelect;
window.ModelListSelect = ModelListSelect;
window.swal = swal;

Vue.use(VueRouter);

const toast = swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000
});

window.toast = toast;

Vue.use(VueProgressBar, {
    color: 'rgb(143, 255, 199)',
    failedColor: 'red',
    height: '4px'
})

window.Form = Form;

window.Fire = new Vue();

Vue.component(HasError.name, HasError);
Vue.component(AlertError.name, AlertError);

let routes = [
    {path: '/', component: require('./components/NotesComponent')},
    {path: '/admin/buildings', component: require('./components/BuildingsComponent')},
    {path: '/admin/groups', component: require('./components/GroupsComponent')},
    {path: '/admin/people', component: require('./components/PeopleComponent')},
    {path: '/search', component: require('./components/SearchComponent')}

]

const router = new VueRouter({
    mode: 'history',
    routes
})

const app = new Vue({
    el: '#app',
    router
});
