<?php

use Illuminate\Http\Request;

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::apiResources([
    'building'  => 'API\BuildingController',
    'group'     => 'API\GroupController',
    'people'    => 'API\PeopleController',
    'note'      => 'API\NoteController'
]);

Route::get('/search', 'API\PeopleController@search');
